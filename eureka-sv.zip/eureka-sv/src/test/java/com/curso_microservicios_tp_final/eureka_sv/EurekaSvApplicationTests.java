package com.curso_microservicios_tp_final.eureka_sv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaSvApplicationTests {

	@Test
	void contextLoads() {
	}

}
